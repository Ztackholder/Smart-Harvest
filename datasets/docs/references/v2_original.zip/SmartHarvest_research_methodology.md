# SmartHarvest Research-Informed Synthetic Dataset v2

**STATUS: 100% SYNTHETIC, not observed harvest ground truth.** Source of truth for the SmartHarvest system is *Laporan Kelompok 09 Deliverable 2 II3120*, Section 3.4.3 and the related APIs. This dataset is a pedagogical prototype and should never be presented as agricultural field validation for Seni Tani.

## Files (generated reproducibly)

| File | Rows | Meaning |
|---|---:|---|
| `SmartHarvest_training_research_4500.csv` | 4,500 | Training with synthetic `actual_harvest_kg` |
| `SmartHarvest_testing_research_752.csv` | 752 | Full labeled holdout for auditing |
| `SmartHarvest_testing_inputs_research_752.csv` | 752 | Same holdout features without the target |
| `SmartHarvest_ground_truth_research_752.csv` | 752 | Synthetic reference labels for the holdout |
| `SmartHarvest_source_audit_research.csv` | 7 | Checked sources, limitations, transfer constraints |
| `SmartHarvest_parameters_research.csv` | 7 | Assumed crop-specific numeric parameters |
| `SmartHarvest_sensitivity_research.csv` | 40 | Generator sensitivity examples, not learned model effects |
| `SmartHarvest_generate_research_dataset.py` | script | Reproducible generator, seed 20261124 |

The two main files preserve the previous **21 columns**. The columns `sensor_source`, `data_origin`, `split` remain excluded. The target is `actual_harvest_kg` in kilograms, aligned to the farm, crop, and week. `soil_moisture_mean_7d_pct` and `soil_moisture_min_7d_pct` are **calibrated relative wetness indices** scaled 0–100, not volumetric water content.

## What was actually learned from the five supplied public datasets

1. Commercial tomato greenhouse, Mendeley `tkbkzdt5nr`: the verifiable latest version v2 documents measured temperature, relative humidity, light, tomato truss weight and other plant states. It supports the relevance of time-aligned climate and harvest measurements. Tomato yields were **not** transferred to leafy vegetables.
2. Tropical/subtropical agriculture Zenodo `18582148`: access to files is **restricted**. Metadata describes Indonesia annual crop yields, precipitation, specific humidity and root-zone soil wetness. Annual area-normalized field-crop values cannot directly calibrate a per-plot weekly yield of spinach or lettuce.
3. Smart Farming Crop Yield 2024 GitHub `CNucc/smart-farming`: all **500 data rows / 22 fields** were inspected. Crop types are wheat, soybean, maize, cotton and rice. Pearson correlations with yield were **soil moisture -0.063; temperature +0.028; relative humidity +0.039; rainfall -0.077**. These near-zero correlations, lack of leafy crops and unverified source realism make the data unsuitable for deriving the simulation's numerical sensitivities.
4. HydroGrowNet Batavia Mendeley `g6cm3v3wdp` v5: describes three 30-day hydroponic lettuce growth experiments synchronized with sensor data and images, mainly nutrient-solution temperature, pH and EC. It supports time alignment and growth-stage modeling, **not** numeric soil moisture calibration for an outdoor soil sensor.
5. Lettuce greenhouse growth-model Mendeley `r7z9ttvkyh` v1: three growing experiments with climate, dry-weight and leaf-area trajectories. It supports nonlinear growth curves, but we did **not** fit any parameters to the raw experimental sheets.

FAO's official soil-water stress reference provides the *direction* of drought effects and shows that water stress depends on root-zone soil properties and the crop. Therefore a capacitive sensor's arbitrary 0–100 scale cannot be mapped directly onto FAO's evapotranspiration-response coefficient. The numeric wetness boundaries and penalties below are **explicit hypothetical model parameters**.

## Generation mechanisms (all functional choices described, parameter values unvalidated)

- **Crop-specific reference yield:** the seven `kg/m2` coefficients in `SmartHarvest_parameters_research.csv` are plausible fictional baseline settings. There is no claim that they are measured Seni Tani or literature averages. The output scales approximately with `planted_area_m2`, adjusted for plant density.
- **Growth stage:** a Gompertz-like biomass function is evaluated at `crop_age_days + days_until_target_harvest`; it grows rapidly and then saturates, with a small optional late-harvest reduction. This replaces the previous arbitrary constant per-day bonus.
- **Temperature:** crop-specific comfortable temperature bands; both cold and heat can reduce growth. Daily maximum extreme temperature contributes an additional bounded heat penalty. Reference optima and coefficients are **assumptions**, not pooled empirical estimates.
- **Humidity and evaporative demand:** mean air temperature and RH are combined through the standard saturation vapor pressure expression (kPa), then a modest high-VPD penalty applies. A separate very-high-RH penalty is included as a synthetic demonstration assumption.
- **Soil wetness:** a relative index below 43 triggers a drought penalty; above 81 an excess-wetness penalty; very low 7-day minimum moisture adds a separate penalty. Breakpoints are **illustrative**, have no universal agronomic validity, and require soil-specific calibration.
- **Plant population:** increasing planting density improves total production from sparsely planted conditions to saturation; crowded conditions produce a small penalty.
- **Correlated inputs:** rainfall-season proxy, farm microclimate, relative humidity, temperature, irrigation propensity and wetness are simulated jointly. These dependencies avoid the previous approach of treating every sensor field as independently random.
- **Variation:** fixed fictional site factors and a log-normal residual introduce realistic measurement/model uncertainty. **Random variation is still present**, as it should be in a synthetic dataset; the *expected yield* depends deterministically on plant, environment and management variables.
- **Missing optional IoT:** approximately 6% of soil sensor summaries are blank. Their underlying synthetic true moisture was used to generate the outcome, but is hidden as missing input. These cases must be handled by imputation or an inference fallback.

A conceptual summary of the expected synthetic quantity is:

`kg = crop_reference_kg_m2 × area_m2 × growth_stage_factor × temperature_factor × heat_extreme_factor × VPD_factor × wetness_factor × dry_spell_factor × plant_density_factor × fictional_farm_factor × fictional_plot_factor × random_residual`

**Do not train with:** `actual_harvest_kg` as an input, `estimated_quantity_kg` (reserve for farmer baseline), `soil_condition` (derived from moisture, redundant), identifiers, `valid_sensor_readings_7d` (quality indicator), or date-derived target leakage. Recommended model inputs: `crop_id`, `planted_area_m2`, `crop_age_days`, `days_until_target_harvest`, `air_temp_mean_7d_c`, `air_temp_max_7d_c`, `humidity_mean_7d_pct`, `soil_moisture_mean_7d_pct`, `soil_moisture_min_7d_pct`, `plant_count`.

## Data integrity and evaluation

- Train: **4,500 rows** across 7 crop categories; test: **752 rows**.
- Training prediction dates: 2021-04-14 to 2025-09-17.
- Testing prediction dates: 2025-10-23 to 2026-08-18.
- Latest training **harvest date**: 2025-09-30; earliest test **prediction date**: 2025-10-23. This prevents using future harvest labels at the time of earliest test predictions.
- The train and test sets share farms/plots but have **no overlapping planting IDs**. This tests out-of-time performance on known farms; leave-one-farm-out evaluation is a separate, stricter experiment.
- Missing soil values: training **256**, test **39**.
- Outcome range in the combined synthetic dataset: **3.79–135.14 kg**. It is a synthetic range, not observed Seni Tani production.
- Validation metrics on these rows measure how accurately a model reproduces **the generator's assumptions**. They cannot establish real yield-prediction accuracy.

## Exact source URLs

- https://data.mendeley.com/datasets/tkbkzdt5nr/2
- https://zenodo.org/records/18582148
- https://github.com/CNucc/smart-farming/blob/main/Smart_Farming_Crop_Yield_2024.csv
- https://data.mendeley.com/datasets/g6cm3v3wdp/5
- https://data.mendeley.com/datasets/r7z9ttvkyh/1
- https://www.fao.org/4/X0490E/x0490e0e.htm
- https://pubmed.ncbi.nlm.nih.gov/33786828/

This revision is intentionally conservative: it incorporates research into feature selection and causal *shape*, while keeping unknown numerical effect sizes transparent and editable.
