#!/usr/bin/env python3
"""SmartHarvest research-informed SYNTHETIC harvest dataset.

Scientific basis is directional / functional, not calibrated crop-specific
quantitative coefficients. See SmartHarvest_research_methodology.md.
No rows from external datasets are copied.
"""
import csv
import math
import random
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

OUT = Path("/mnt/data")
SEED = 20261124
RNG = random.Random(SEED)
TZ = timezone(timedelta(hours=7))
N_TRAIN, N_TEST = 4500, 752

CROPS = {
    "AMARANTH":       dict(kg_m2=1.35, temp_opt=27.0, temp_tol=2.5, mature=30, density=14.0, drought=.36, waterlog=.22, growth_k=.16),
    "KANGKUNG":       dict(kg_m2=1.50, temp_opt=28.0, temp_tol=3.0, mature=29, density=16.0, drought=.31, waterlog=.22, growth_k=.16),
    "LETTUCE":        dict(kg_m2=1.65, temp_opt=22.0, temp_tol=2.5, mature=39, density=8.0, drought=.44, waterlog=.27, growth_k=.13),
    "PAKCHOY":        dict(kg_m2=1.85, temp_opt=24.0, temp_tol=2.5, mature=35, density=9.0, drought=.39, waterlog=.24, growth_k=.14),
    "MUSTARD_GREENS": dict(kg_m2=1.55, temp_opt=25.0, temp_tol=2.5, mature=34, density=12.0, drought=.37, waterlog=.24, growth_k=.14),
    "SPINACH":        dict(kg_m2=1.20, temp_opt=21.0, temp_tol=3.0, mature=34, density=10.0, drought=.43, waterlog=.24, growth_k=.14),
    "KALE":           dict(kg_m2=1.45, temp_opt=21.0, temp_tol=3.5, mature=47, density=6.0, drought=.34, waterlog=.25, growth_k=.105),
}

HEADERS = [
 "farm_id","plot_id","planting_id","crop_id","planting_date","prediction_at",
 "target_harvest_date","target_period","planted_area_m2","crop_age_days",
 "days_until_target_harvest","air_temp_mean_7d_c","air_temp_max_7d_c",
 "humidity_mean_7d_pct","soil_moisture_mean_7d_pct","soil_moisture_min_7d_pct",
 "plant_count","estimated_quantity_kg","actual_harvest_kg","soil_condition",
 "valid_sensor_readings_7d"
]

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def vpd_kpa(t, rh):
    # FAO-56 saturation vapor pressure equation, based on temperature and RH.
    saturation = 0.6108 * math.exp(17.27 * t / (t + 237.3))
    return saturation * (1.0 - rh/100.)

def relative_yield(crop, area, age_now, horizon, tmean, tmax, rh, soil_mean, soil_min, nplants):
    """Documented agronomic-shape assumptions. Multipliers are NOT fitted to field data."""
    c = CROPS[crop]
    harvest_age = age_now + horizon

    # Gompertz-like crop biomass accumulation.
    def growth(age):
        return math.exp(-math.exp(-c["growth_k"] * (age - 0.59*c["mature"])))
    age_ratio = growth(harvest_age) / growth(c["mature"])
    age_factor = clamp(age_ratio, .19, 1.11)
    if harvest_age > c["mature"] + 6:
        age_factor *= clamp(1 - .005 * (harvest_age - c["mature"] - 6), .91, 1.0)

    # Crop-specific comfortable daytime-mean band, asymmetrical heat/cold effects.
    distance = abs(tmean - c["temp_opt"])
    deviation = max(0., distance - c["temp_tol"])
    t_factor = clamp(1 - deviation * (.033 if tmean > c["temp_opt"] else .023), .55, 1.0)
    high_extreme = c["temp_opt"] + c["temp_tol"] + 4.5
    heat_factor = clamp(1.0 - .014 * max(0., tmax - high_extreme), .83, 1.0)

    # Relative humidity combines with temperature through evaporative demand.
    vpd = vpd_kpa(tmean, rh)
    vpd_factor = clamp(1.0 - .072 * max(0., vpd - 1.3), .82, 1.0)
    excessive_humid_penalty = clamp(1.0 - .0026 * max(0., rh - 88), .96, 1.0)

    # The sensor values are calibrated RELATIVE WETNESS INDICES, not volumetric content.
    # Deficit/saturation breakpoints are MODEL ASSUMPTIONS, NOT FAO thresholds.
    deficit = clamp((43.0 - soil_mean) / 33.0, 0, 1)
    waterlog = clamp((soil_mean - 81.0) / 16.0, 0, 1)
    moisture_factor = 1 - c["drought"] * deficit - c["waterlog"] * waterlog
    very_dry_min = clamp((29.0 - soil_min) / 22.0, 0, 1)
    min_factor = 1 - .095 * very_dry_min

    # Competition: plant population benefit saturates at a reference density.
    density_ratio = (nplants/max(1.,area)) / c["density"]
    density_factor = clamp(density_ratio ** .42, .65, 1.02)
    if density_ratio > 1.22:
        density_factor *= clamp(1 - .14 * (density_ratio - 1.22), .88, 1.0)

    return (
       c["kg_m2"] * area * age_factor * t_factor * heat_factor *
       vpd_factor * excessive_humid_penalty * moisture_factor *
       min_factor * density_factor
    )

def write_csv(filename, rows, headers):
    path = OUT / filename
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)
    return path

# Persistent fictional microclimate + growing conditions create repeated-site structure.
farms = {
    f: dict(
        mean_temp = RNG.uniform(22, 28.5),
        rh_bias = RNG.uniform(-6, 7),
        production_factor = RNG.uniform(.87, 1.13),
        irrigation_factor = RNG.uniform(-9, 11),
    )
    for f in range(1, 33)
}
plots = {
    (f,p): dict(
        area_base = RNG.uniform(6.5, 53),
        production_factor = RNG.uniform(.92, 1.08),
        water_bias = RNG.uniform(-8, 8),
    )
    for f in range(1, 33) for p in range(1, 11)
}
# Reserve entire later growing cycles for a chronological, leakage-resistant test set.
train_keys = [(f,p,cycle) for f in range(1,33) for p in range(1,11) for cycle in range(15)]
test_keys = [(f,p,cycle) for f in range(1,33) for p in range(1,11) for cycle in range(15,18)]
RNG.shuffle(train_keys)
RNG.shuffle(test_keys)
keys = train_keys[:N_TRAIN] + test_keys[:N_TEST]

rows = []
crop_keys = list(CROPS)
for f, p, cycle in keys:
    farm = farms[f]
    plot = plots[f,p]
    crop_id = RNG.choice(crop_keys)
    crop = CROPS[crop_id]
    farm_id = f"FARM-{f:02d}"
    plot_id = f"PLOT-{f:02d}-{p:02d}"
    planting_id = f"PLANT-{f:02d}-{p:02d}-{cycle+1:02d}"

    # Each plot's successive planting cycles are separated by ~110 days;
    # a cycle gap lets all training harvests precede test prediction dates.
    planting_date = date(2021,4,1) + timedelta(days=110*cycle+(f*13+p*9)%48+RNG.randint(0,6))
    harvest_age = max(18, crop["mature"] + RNG.randint(-8,8))
    horizon = RNG.randint(2,min(14,harvest_age-10))
    age_now = harvest_age - horizon
    prediction_date = planting_date + timedelta(days=age_now)
    harvest_date = planting_date + timedelta(days=harvest_age)
    iso = harvest_date.isocalendar()
    target_period = f"{iso.year}-W{iso.week:02d}"

    area = round(clamp(plot["area_base"]*RNG.uniform(.83,1.17),4.0,62.0),2)
    density_ratio = RNG.uniform(.62,1.38)
    nplants = round(max(1, area*crop["density"]*density_ratio))

    rainy = planting_date.month in (11,12,1,2,3,4)
    temp_mean = round(clamp(farm["mean_temp"] + (-.55 if rainy else .65) + RNG.gauss(0,2.45), 17, 35),2)
    temp_max = round(clamp(temp_mean + RNG.uniform(2.6,8.7) + (.5 if not rainy else 0),temp_mean+1,43),2)

    # Temperature, rain season, farm and irrigation share latent influences.
    humidity = round(clamp(
        72 + farm["rh_bias"] + (8 if rainy else -6) -
        .92*(temp_mean-25.0) + RNG.gauss(0,7.1),
        43,96
    ),2)

    latent_moisture = (
        52 + (12 if rainy else -7) + farm["irrigation_factor"]
        + plot["water_bias"] - 1.13*(temp_mean-25)
        + .21*(humidity-70) + RNG.gauss(0,14)
    )
    soil_mean = round(clamp(latent_moisture,12,96),2)
    soil_min = round(clamp(soil_mean - RNG.uniform(4,17) - .25*max(0,temp_max-31),2,soil_mean),2)
    soil_condition = ("dry" if soil_mean < 43 else
                      "adequate" if soil_mean <= 75 else
                      "wet" if soil_mean <= 81 else "saturated")

    base_expected = relative_yield(crop_id, area, age_now, horizon, temp_mean,
                                  temp_max, humidity, soil_mean, soil_min, nplants)
    # Lognormal residual variation with fixed farm/plot heterogeneity and season effects.
    residual = math.exp(RNG.gauss(-.5*.07**2, .07))
    actual = round(max(.1, base_expected * farm["production_factor"] *
                             plot["production_factor"] * residual), 2)

    # Farmer's forecast exists only for baseline comparison, not as an ML input.
    estimate = round(max(.1, CROPS[crop_id]["kg_m2"]*area *
                           clamp(RNG.gauss(0.97,.18),.55,1.40)),2)

    # Missing soil observations are optional; labels still depend on latent conditions.
    missing = RNG.random() < .06
    valid = RNG.randint(470,672) if not missing else RNG.randint(170,620)
    row = {
       "farm_id":farm_id, "plot_id":plot_id,"planting_id":planting_id,
       "crop_id":crop_id, "planting_date":planting_date.isoformat(),
       "prediction_at":datetime.combine(prediction_date,datetime.min.time(),tzinfo=TZ).replace(hour=9).isoformat(),
       "target_harvest_date":harvest_date.isoformat(),
       "target_period":target_period,"planted_area_m2":area,
       "crop_age_days":age_now, "days_until_target_harvest":horizon,
       "air_temp_mean_7d_c":temp_mean, "air_temp_max_7d_c":temp_max,
       "humidity_mean_7d_pct":humidity,
       "soil_moisture_mean_7d_pct":"" if missing else soil_mean,
       "soil_moisture_min_7d_pct":"" if missing else soil_min,
       "plant_count":nplants,"estimated_quantity_kg":estimate,
       "actual_harvest_kg":actual,
       "soil_condition":"unavailable" if missing else soil_condition,
       "valid_sensor_readings_7d":valid
    }
    rows.append(row)

rows.sort(key=lambda r:(r["prediction_at"],r["planting_id"]))
train = rows[:N_TRAIN]
test = rows[N_TRAIN:]
assert len(rows)==5252 and len(train)==4500 and len(test)==752
assert len({r["planting_id"] for r in rows}) == len(rows)
assert max(r["target_harvest_date"] for r in train) < min(r["prediction_at"][:10] for r in test)
assert all(set(r.keys())==set(HEADERS) for r in rows)
assert all(r["soil_moisture_min_7d_pct"]=="" or float(r["soil_moisture_min_7d_pct"]) <= float(r["soil_moisture_mean_7d_pct"]) for r in rows)

truth_cols = ["farm_id","plot_id","planting_id","crop_id",
              "prediction_at","target_harvest_date","target_period","actual_harvest_kg"]
write_csv("SmartHarvest_training_research_4500.csv", train, HEADERS)
write_csv("SmartHarvest_testing_research_752.csv", test, HEADERS)
write_csv("SmartHarvest_testing_inputs_research_752.csv", [{k:v for k,v in r.items() if k!="actual_harvest_kg"} for r in test], [x for x in HEADERS if x!="actual_harvest_kg"])
write_csv("SmartHarvest_ground_truth_research_752.csv", [{k:r[k] for k in truth_cols} for r in test], truth_cols)

if __name__=="__main__":
    from collections import Counter
    print("Wrote train/test/inputs/ground-truth:",len(train),len(test))
    print("Training crops:",dict(Counter(r["crop_id"] for r in train)))
    print("Testing crops:",dict(Counter(r["crop_id"] for r in test)))
    print("Date range:",train[0]["prediction_at"],test[-1]["prediction_at"])
    print("Mean actual kg:",round(sum(r["actual_harvest_kg"] for r in rows)/len(rows),2))
    print("Missing soil:",sum(r["soil_moisture_mean_7d_pct"]=="" for r in rows))
